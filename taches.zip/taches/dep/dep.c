
#include "dep.h"

 void initialiser (Objet *perso ) 
 {
  perso->img=IMG_Load("detective.png") ;
  perso->pos.x=0 ;
  perso->pos.y=0 ;
 }

